import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss'],
})
export class ProductDetailComponent implements OnInit {
  // 待查询的商品编号--来自于商品列表页
  private pid='';

  constructor(private route:ActivatedRoute,private http:HttpClient) { }

  ngOnInit() {
    // 读取商品列表传递建磊的商品编号--路由参数
    this.route.params.subscribe((data)=>{
      this.pid=data.pid;
    })
    // 根据商品编号查询商品详情
    // http://www.codeboy.com/data/product/details.php?lid=xxx;
    // 发http请求...
  }

}
