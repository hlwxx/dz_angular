// import { Component, OnInit } from '@angular/core';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonInfiniteScroll } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
})
export class CartComponent implements OnInit {
  // 模型数据--成员属性 初始值为1
  count=1;

  // 购物车列表
  private cartList=[];

 // 当前加载的页号
 private pno=0;
 // 还有更多数据吗? 初始化为true
 private hasMore=true;

 // 获取模板中无穷滚动组件的引用
 @ViewChild(IonInfiniteScroll,{static:true})
 private myScroll:IonInfiniteScroll;

  constructor(private nav:NavController,private http:HttpClient) {}

  ngOnInit() {
    this.pno++;
    let url='http://www.codeboy.com/data/product/list.php?pno='+this.pno;
    this.http.get(url).subscribe((res:any)=>{
      console.log(res);
      this.cartList=this.cartList.concat(res.data);
      console.log(this.cartList);
    });
  }

  loadMore() {
    this.pno++;
    // let url='http://www.codeboy.com/data/cart/list.php?pno='+this.pno;
    let url='http://www.codeboy.com/data/product/list.php?pno='+this.pno;
    this.http.get(url).subscribe((res:any)=>{
      console.log(res);
      this.cartList=this.cartList.concat(res.data);
      console.log(this.cartList);
      this.myScroll.complete();//隐藏无限滚动属性
      if(this.pno>=res.pageCount){ //pageCount是服务器端数据
        this.hasMore=false;//没有更多数据了 全部加载完成
      }
    });
  }

  // 模型数据--成员方法--增加
  inc(){
    
    this.count++;
  }

  // 模型数据--成员方法--减少
  desc(){
    this.count--;
  }

}


