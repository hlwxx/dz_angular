import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IonSlides } from '@ionic/angular';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss'],
})
export class IndexComponent implements OnInit {
  private carouselItems=[];//轮播广告数据
  private newArrivalItems=[];//新品上市数据
  private recommendedItems=[];//热销单品数据
  private topSaleItems=[]; //首页推荐数据

  private slideOpts ={ //轮播广告选项
    initialSlide:0,//初始显示第几个广告
    speed:400,//滑动速度 (毫秒)
    // loop:true, //无缝轮播
  };

  // 在组件的脚本中引用自己模板中的视图子组件
  @ViewChild(IonSlides,{static:true})//视图组件的孩子
  private mySlides:IonSlides;

  constructor(private http:HttpClient) { }

  ngOnInit() {
    // 首页组件初始化时，异步请求服务器端的首页数据
    let url='http://www.codeboy.com/data/product/index.php';
    this.http.get(url).subscribe((res:any)=>{ //订阅 回调函数
      console.log(res);
      this.carouselItems=res.carouselItems;
      this.newArrivalItems=res.newArrivalItems;
      this.recommendedItems=res.recommendedItems;
      this.topSaleItems=res.topSaleItems;
      // 开始轮播广告的自动播放
      console.log(this.mySlides);
      this.mySlides.startAutoplay();
    })
  }

}
